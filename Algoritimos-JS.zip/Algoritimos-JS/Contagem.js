var n = parseInt(prompt("Qual o número?"));
for(var i = 0;i <= n;i++){
    console.log(i);
}